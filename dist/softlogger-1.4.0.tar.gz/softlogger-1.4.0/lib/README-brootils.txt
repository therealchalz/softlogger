BROOTILS

This is a utility library written in Java.  It has the following helpers/functionality:

-CSV file writing
-Email sending
-SSH (port forwarding and SCP)
-XML file loading

It also has the following beta functionality:

-Thread performance monitoring

DEPENDENCIES
All portions of the library depend on log4j-api-2.5 and log4j-core-2.5.jar.

The email sending requires the java mail.jar and activation.jar.

The SSH portions require jsch-0.1.53.jar.